import can from "can";
import template from "./report.stache!";
import "./report.less!";



export default can.Component.extend(
{
	tag: "page-report",
	template: template,
	scope:
	{
		
	}
});
